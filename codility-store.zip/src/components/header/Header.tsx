import { HeaderContainer } from './Header.module'

const Header = () => {
  return (
    <HeaderContainer>
      <h1>Codility Store</h1>
    </HeaderContainer>
  )
}

export default Header