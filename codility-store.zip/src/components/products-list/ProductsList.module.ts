import styled from "styled-components";

export const ProductsListPage = styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  min-height: 100%;
  align-items: flex-start;
  padding: 1rem;
  border: 1px solid #b2b2b2;
  background-color: #f1f1f1;
`

export const ProductItemContainer = styled.div`
  display: flex;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  padding: 1rem;
  border: 2px solid #c1c1c1;
  background-color: #fff;
  border-radius: 4px;
  align-items: center;
  justify-content: flex-start;
`

export const ProductsListContainer = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 1rem;
  max-width: 100%;
  height: 100%;
`

export const ProductDetailInfo = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: 0rem 2rem;
  max-width: 80%;
  height: 100%;
  box-sizing: border-box;
  gap: 6px 0;
`

export const DeleteBtn = styled.button`
  display: flex;
  position: absolute;
  bottom: 0;
  right: 0;
  outline: none;
  border: none;
  padding: 6px 18px;
  background: firebrick;
  color: #fff;
  margin: 1rem;
  cursor: pointer;
  border-radius: 4px;
  &:hover {
    filter: brightness(0.9);
  }
`