import { ProductProps } from "../../lib/store"
import { DeleteBtn, ProductDetailInfo, ProductItemContainer } from "./ProductsList.module"

interface ProductItemProps {
  product: ProductProps
}

const ProductItem = ({product}: ProductItemProps) => {
  return (
    <ProductItemContainer>
      <img src="" alt="" width={100} height={100} style={{border: '1px solid #333'}} />
      <ProductDetailInfo>
        <h4>{product.name}</h4>
        <span>{product.description}</span>
      </ProductDetailInfo>
      <DeleteBtn>Delete</DeleteBtn>
    </ProductItemContainer>
  )
}

export default ProductItem