import { useDispatch, useSelector } from "react-redux"
import Actions from "./Actions"
import ProductItem from "./ProductItem"
import { ProductsListContainer, ProductsListPage } from "./ProductsList.module"
import { RootState } from "../../lib/store"
import { useState } from "react"

const ProductsList = () => {

  const products = useSelector((state: RootState) => state.products);
  const dispatch = useDispatch();

  const [filtered, setFiltered] = useState(products);
  
  return (
    <ProductsListPage>
      <h2>PRODUCTS</h2>
      <br />
      <Actions {...{ products, setFiltered }} />
      <br />
      <ProductsListContainer>
      {filtered.map((product) => {
        return <ProductItem key={product.id} product={product} />
      })}
      </ProductsListContainer>
    </ProductsListPage>
  )
}

export default ProductsList