import { SetStateAction, useState } from "react"
import { ProductProps } from "../../lib/store"
import { ActionsContainer, AddProductBtn, SearchBar, SortBySelect } from "./Actions.module"

interface ActionProps {
  products: ProductProps[];
  setFiltered: React.Dispatch<SetStateAction<ProductProps[]>>;
}

const Actions = ({ products, setFiltered }: ActionProps) => {

  const [searchValue, setSearchValue] = useState<string>('');

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.toLowerCase()
    setSearchValue(value)
    if(!searchValue) {
      return 
    } else {
      setFiltered(() => products.filter(el => {
        return el.description.toLowerCase().includes(value) || el.name.toLowerCase().includes(value)
      }))
    }
  }

  return (
    <ActionsContainer>
      <AddProductBtn>+ Add</AddProductBtn>
      <SearchBar placeholder="Search product..." type="text" value={searchValue} onChange={handleSearch}/>
      <label htmlFor="sort-by"></label>
      <SortBySelect name="sort-by" id="sort-by">
        <option value="name">Name</option>
        <option value="recently-added">Recently Added</option>
      </SortBySelect>
    </ActionsContainer>
  )
}

export default Actions