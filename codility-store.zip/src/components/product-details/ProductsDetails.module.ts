import styled from "styled-components";

export const ProductsDetailsContainer = styled.div`
  display: block;
  position: relative;
  width: 100%;
  align-items: flex-start;
  padding: 3rem;
  text-transform: uppercase;
  border: 1px solid #b2b2b2;
  background-color: #f1f1f1;
`

export const ProductDetailsDiv = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 1rem;
  padding: 0rem;
  width: 100%;
  height: 100%;
  & > div {
    display: flex;
    width: 100%;
    flex-direction: column;
    & > textarea, input {
      width: 100%;
      resize: none;
      padding: 10px;
      background-color: #fff;
      outline: none;
      border: 1px solid #ccc;
      margin: 10px 0;
    }
  }
`

export const ProductImg = styled.img`
  width: 200px;
  height: 200px;
  border: 1px solid #333;
  background: #fff;
`

export const SaveBtn = styled.button`
  padding: 6px 20px;
  width: 100px;
  background-color: lightgreen;
  color: #444;
  border-radius: 15px;
  outline: none;
  border: none;
  cursor: pointer;
  font-weight: bold;
`