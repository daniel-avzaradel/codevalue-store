import { ProductProps } from "../../lib/store"
import { ProductDetailsDiv, ProductImg, ProductsDetailsContainer, SaveBtn } from "./ProductsDetails.module"

interface ProductDetailsProps {
  product: ProductProps
}

const ProductDetails = ({ product }: ProductDetailsProps) => {
  return (
    <ProductsDetailsContainer>
      <h2>Product Details</h2>
      <br />
      <br />
      <ProductDetailsDiv>
        <ProductImg />
        <br />
        <div>
          <label htmlFor="name">Name</label>
          <input type="text" id="name" value={product.name} readOnly />
        </div>
        <div>
          <label htmlFor="desc">Description</label>
          <textarea id="desc" value={product.description} rows={5} readOnly />
        </div>
        <div style={{maxWidth: '80px'}}>
          <label htmlFor="price">Price</label>
          <input id="price" value={product.price} readOnly />
        </div>
      <SaveBtn>SAVE</SaveBtn>
      </ProductDetailsDiv>
    </ProductsDetailsContainer>
  )
}

export default ProductDetails