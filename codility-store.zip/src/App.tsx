import { useState } from "react"
import { MainContainer, ProductsSection } from "./App.module"
import Header from "./components/header/Header"
import ProductDetails from "./components/product-details/ProductDetails"
import ProductsList from "./components/products-list/ProductsList"
import { useSelector } from "react-redux"
import { RootState } from "./lib/store"

function App() {

  // sorry, I only had a couple of hours to work on this. far from finishing the project.

  const products = useSelector((state: RootState) => state.products);
  const [selectedProduct, setSelectedProduct] = useState(products[0])

  return (
    <MainContainer>
      <Header />
      <ProductsSection>
        <ProductsList />
        <ProductDetails product={selectedProduct} />
      </ProductsSection>
    </MainContainer>
  )
}

export default App
