import { createSlice } from "@reduxjs/toolkit";
import { products } from "./products";

const productsSlice = createSlice({
  name: 'products',
  initialState: products,
  reducers: {
    addProduct: (state, action) => {
      state.push(action.payload)
    }
  }
});

export const { addProduct } = productsSlice.actions;
export default productsSlice.reducer