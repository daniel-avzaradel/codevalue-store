import { ProductProps } from "./store";

export const products: ProductProps[] = [
  {
    id: 1,
    name: "Wireless Earbuds",
    description: "High-quality wireless earbuds with noise cancellation and 12-hour battery life.",
    price: 59.99,
    creation_date: new Date("2025-01-01"),
  },
  {
    id: 2,
    name: "Smart Fitness Tracker",
    description: "A lightweight fitness tracker that monitors heart rate, steps, and sleep patterns.",
    price: 89.99,
    creation_date: new Date("2024-12-15"),
  },
  {
    id: 3,
    name: "Ergonomic Office Chair",
    description: "Comfortable and adjustable office chair with lumbar support and breathable mesh fabric.",
    price: 199.99,
    creation_date: new Date("2024-11-30"),
  },
  {
    id: 4,
    name: "4K Action Camera",
    description: "Durable 4K action camera with waterproof casing and multiple shooting modes.",
    price: 129.99,
    creation_date: new Date("2024-10-22"),
  },
  {
    id: 5,
    name: "Portable Bluetooth Speaker",
    description: "Compact Bluetooth speaker with powerful sound and up to 10 hours of playtime.",
    price: 39.99,
    creation_date: new Date("2024-09-15"),
  },
];